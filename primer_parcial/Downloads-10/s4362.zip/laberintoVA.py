import copy
'''
def imprimir(laberinto, n, m):
    for i in range(n):
        for j in range(m):
            print(laberinto[i][j], end='\t')
        print()
    print()
    print()
'''
def esSolucion(initx, inity, endx, endy, enemigosEliminados, enemigosMaximos):
    return initx == endx and inity == endy and enemigosEliminados == enemigosMaximos

def esMejor(laberinto, mejorSol, endx, endy):
    if laberinto[endy][endx] < mejorSol[endy][endx]:
        return copy.deepcopy(laberinto)
    else:
        return mejorSol

def esFactible(laberinto, x, y, n, m):
    if 0 <= x < m and 0 <= y < n:
        return laberinto[y][x] == -1 or laberinto[y][x] == 0

def poda(mejorSol, x, y, k):
    return k < mejorSol[y][x]

def laberintoVA(laberinto, mejorSol, initx, inity, endx, endy, k, n, m, enemigosEliminados, enemigosMaximos):
    # imprimir(laberinto, n, m)
    if esSolucion(initx, inity, endx, endy, enemigosEliminados, enemigosMaximos):
        # print("SOLUCION SOLUCION")
        mejorSol = esMejor(laberinto, mejorSol, endx, endy)
    else:
        if poda(mejorSol, endx, endy, k):
            movimientos = [(0, 1), (1, 0), (0, -1), (-1, 0)]
            for dx, dy in movimientos:
                if esFactible(laberinto, initx + dx, inity + dy, n, m):
                    enemigos = []
                    if laberinto[inity + dy][initx + dx] == -1:
                        enemigosEliminados += 1
                        enemigos.append((inity + dy, initx + dx))
                    laberinto[inity + dy][initx + dx] = k
                    mejorSol = laberintoVA(laberinto, mejorSol, initx + dx, inity + dy, endx, endy, k + 1, n, m, enemigosEliminados, enemigosMaximos)
                    laberinto[inity + dy][initx + dx] = 0
                    while enemigos:
                        (ex, ey) = enemigos.pop()
                        laberinto[ex][ey] = -1
                        enemigosEliminados -= 1
    return mejorSol

laberinto = []
n, m, enemigosMaximos = map(int, input().strip().split())
inity, initx = map(int, input().strip().split())
endy, endx = map(int, input().strip().split())
for _ in range(n):
    linea = list(map(int, input().strip().split()))
    laberinto.append(linea)
mejorSol = copy.deepcopy(laberinto)
mejorSol[endy][endx] = float('inf')
laberinto[inity][initx] = 1
enemigosEliminados = 0
sol = laberintoVA(laberinto, mejorSol, initx, inity, endx, endy, 2, n, m, enemigosEliminados, enemigosMaximos)
# imprimir(sol, n, m)
print(sol[endy][endx])
'''
4 5 3
0 1
0 3
0 0 0 0 0
-2 0 0 -2 0
-2 0 -1 -2 0
0 0 -1 0 -1
'''